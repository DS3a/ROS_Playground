#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import numpy as np
import time
from tf.transformations import euler_from_quaternion
import os

X = [0]
Theta = [0]
def got_pose(pose: Odometry):
    X[0] = pose.pose.pose.position.x
    q = pose.pose.pose.orientation
    _x, _y, z = euler_from_quaternion([q.x, q.y, q.z, q.w])
    Theta[0] = z
rospy.init_node("ebot_controller")
vel_publisher = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
odom_listener = rospy.Subscriber('/odom', Odometry, got_pose)


def y(x):
    return 2.0 * np.sin(x) * np.sin(x/2)

def dy_dx(x):
    return 2 * np.cos(x) * np.sin(x/2) + np.sin(x) * np.cos(x/2)


dt = 1e-5 # accuracy of the algorithm
vel = 0.3

X_init = 0.0
X_final = 2*np.pi
T = 0 # radians

while not rospy.is_shutdown():
    destination_reached = False
    vel_msg = Twist()
    time_prev = time_init = time.time()
    while not destination_reached:
        time_curr = time.time() - time_init
        vel_msg.linear.x = vel
        der = dy_dx(X[0])
        req_T = np.arctan(der)
        os.system('clear')
        print(req_T*90/np.pi, T*90/np.pi, (T - req_T)/(time_curr - time_prev))
        vel_msg.angular.z = (T - req_T)/(time_curr - time_prev) * 1.2e10
        vel_publisher.publish(vel_msg)
        T = Theta[0]
        time_prev = time.time()
        if X[0] >= X_final:
            vel_msg = Twist()
            vel_publisher.publish(vel_msg)
            destination_reached = True
    
    if destination_reached:
        break